#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <math.h>

#include "extApi.h"
#include "simConst.h"

#define PI 3.141593
#define LEFT -1
#define RIGHT 1
#define max(X,Y) ((X) > (Y) ? (X) : (Y))